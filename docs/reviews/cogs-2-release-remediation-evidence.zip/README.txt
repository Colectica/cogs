COGS 2.0 native-type remediation evidence, 2026-10-05

Base: 9c5c7c354d2a4a95d89d2a1e46146a2d9fa874da, with the supplied source overlay.
The historical release review and its archive were preserved.
This archive describes local Windows execution, not hosted CI or Linux.

To reconstruct in a fresh disposable checkout at the base revision:
- Apply tracked-changes.patch.
- Copy source-overlay/ over that checkout. It includes the user's existing
  .editorconfig as an input, not as an assistant-authored product change.
- Verify source-sha256.json. It records final source bytes, including newline
  encodings. The overlay preserves final bytes for changed and new source files.
- Provision tools from conformance/tools.json. The local resolved executables
  and versions are in tool-versions.json. Use portable COGS_PYTHON, COGS_NODE,
  COGS_NPM and COGS_DOT variables as described by AGENTS.md.
- Run the build, generation and test steps in workflow.yml. The generation
  harnesses under reproduce/ are the local forms of those steps; use them ONLY
  from a disposable checkout, since generate-all.ps1 replaces its generated/
  child. Set RUNNER_TEMP to a disposable local directory before running it.
- Test-GeneratedRuntimes.ps1 must run twice, with default python and with
  -PythonFlavor python-pydantic. Test-NativeScalars.ps1 runs both Python flavors.
- The local native and chain runs explicitly selected
  out/cogs-native-work/source/generated/conformance with -GeneratedRoot.
  The main workspace's original generated/ was preserved.

Commands for the final verification:
dotnet build Cogs.Console.sln -c Release --no-restore --verbosity minimal
dotnet test Cogs.Tests/Cogs.Tests.csproj -c Release --no-restore
pwsh -NoProfile -File conformance/scripts/Test-Conformance.ps1 -CogsDll Cogs.Console/bin/Release/net10.0/cogs.dll
pwsh -NoProfile -File conformance/scripts/Test-NativeScalars.ps1 -CogsDll Cogs.Console/bin/Release/net10.0/cogs.dll -GeneratedRoot <generated-conformance> -OutputRoot <fresh-results>
pwsh -NoProfile -File conformance/scripts/Test-GeneratedRuntimes.ps1 -CogsDll Cogs.Console/bin/Release/net10.0/cogs.dll -GeneratedRoot <generated-conformance>
pwsh -NoProfile -File conformance/scripts/Test-GeneratedRuntimes.ps1 -CogsDll Cogs.Console/bin/Release/net10.0/cogs.dll -GeneratedRoot <generated-conformance> -PythonFlavor python-pydantic
dotnet restore Cogs.Tests.Integration/Cogs.Tests.Integration.csproj
dotnet test Cogs.Tests.Integration/Cogs.Tests.Integration.csproj -c Release --no-restore
python -m sphinx -W -b dirhtml docs/source <docs-output>
dotnet pack Cogs.Console/Cogs.Console.csproj -c Release --no-build

Integration tests ran inside the disposable source copy after generation.
The final NuGet was installed with a fresh NUGET_PACKAGES cache and
dotnet tool install cogs --version 2.0.0 --tool-path <fresh-local-tools>
--configfile <local-package-only-config> --no-cache. That installed executable
validated conformance/model and generated a standalone C# project that built.

results.json summarizes actual passing observations. The TRX files contain
individual test outcomes. native-boundaries includes 104 independent input
documents and all 464 outputs that were validated by the native scalar gate.
PowerShell Write-Host messages were captured in the interactive execution;
some local logs contain only redirected native-process output. The passing
counts in results.json record the completed gates and are checked against the
stored documents and TRX files when this bundle is assembled.

The full regeneration manifests compare all 246 originally generated files.
After final small runtime corrections, affected publishers were generated twice
again and compared. Turtle compares strict RDF graph isomorphism; syntax bytes
are not its repeatability contract. The other files compare byte-for-byte.

Secondary validation uses repository semantic DCTAP and UML/XMI checkers,
LinkML generation/lint, GraphQL schema parsing, OWLAPI RDF/profile validation,
and Sphinx -W. LinkML recommendation warnings are allowed by --ignore-warnings.
Local OWLAPI used Java 11, not the manifest's hosted Java 21. Profile success
does not prove reasoning or lossless huge-cardinality OWLAPI round trips.
Pinned SDTL/DDI migration-error snapshots passed across all publisher commands;
they do not establish successful downstream generation or instance migration.

No final-tree hosted Windows/Ubuntu or Linux result is claimed.
SHA256SUMS covers every other archive member; the archive also passed ZIP CRC
integrity verification after creation.
