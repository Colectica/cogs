$generated = [IO.Path]::GetFullPath((Join-Path $PWD 'generated'))
$workspace = [IO.Path]::GetFullPath($PWD)
if (-not $generated.StartsWith($workspace + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) {
  throw "Unsafe generated path: $generated"
}
if (Test-Path -LiteralPath $generated) { Remove-Item -LiteralPath $generated -Recurse -Force }

$cogs = [IO.Path]::GetFullPath('./Cogs.Console/bin/Release/net10.0/cogs.dll')
function Invoke-Cogs {
  & dotnet $cogs @args
  if ($LASTEXITCODE -ne 0) { throw "cogs $($args -join ' ') failed with exit $LASTEXITCODE" }
}
function Publish-All([string] $model, [string] $root, [switch] $IntegrationLayout) {
  Invoke-Cogs validate $model
  Invoke-Cogs publish-xsd --overwrite $model "$root/xsd"
  Invoke-Cogs publish-cs --overwrite --csproj --nullable $model "$root/src"
  Invoke-Cogs publish-py --overwrite $model "$root/python"
  Invoke-Cogs publish-py --flavor pydantic --overwrite $model "$root/python-pydantic"
  Invoke-Cogs publish-ts --overwrite $model "$root/typescript"
  Invoke-Cogs publish-json --overwrite $model "$root/json"
  Invoke-Cogs publish-owl --overwrite $model "$root/owl"
  Invoke-Cogs publish-linkml --overwrite $model "$root/linkml"
  Invoke-Cogs publish-dctap --overwrite $model "$root/dctap"
  Invoke-Cogs publish-graphql --overwrite $model "$root/graphql"
  Invoke-Cogs publish-uml --overwrite --mode normative $model "$root/uml-normative"
  Invoke-Cogs publish-uml --overwrite --mode ea --dot $env:COGS_DOT $model "$root/uml-ea"
  Invoke-Cogs publish-dot --overwrite --format dot --all --inheritance --composite $model "$root/dot"
  Invoke-Cogs publish-dot --overwrite --dot $env:COGS_DOT --format svg --all --inheritance --composite $model "$root/dot-svg"
  if ($IntegrationLayout) {
    Invoke-Cogs publish-dot --overwrite --dot $env:COGS_DOT --format png --all --inheritance --composite $model "$root/dot-png"
    Invoke-Cogs publish-dot --overwrite --dot $env:COGS_DOT --format jpeg --all --inheritance --composite $model "$root/dot-jpeg"
  }
  Invoke-Cogs publish-sphinx --overwrite --dot $env:COGS_DOT $model "$root/sphinx"
}

function Get-TreeManifest([string] $root) {
  $resolvedRoot = [IO.Path]::GetFullPath($root)
  @(Get-ChildItem -LiteralPath $resolvedRoot -Recurse -File | ForEach-Object {
    $relative = [IO.Path]::GetRelativePath($resolvedRoot, $_.FullName).Replace('\', '/')
    if ($_.Extension -ieq '.ttl') {
      # Turtle syntax may differ while representing the same RDF graph.
      "$relative`t<RDF-GRAPH>"
    }
    else {
      "$relative`t$((Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash)"
    }
  } | Sort-Object)
}

function Copy-TurtleTree([string] $source, [string] $target) {
  $resolvedSource = [IO.Path]::GetFullPath($source)
  [IO.Directory]::CreateDirectory($target) | Out-Null
  Get-ChildItem -LiteralPath $resolvedSource -Recurse -File |
    Where-Object { $_.Extension -ieq '.ttl' } |
    ForEach-Object {
      $relative = [IO.Path]::GetRelativePath($resolvedSource, $_.FullName)
      $destination = Join-Path $target $relative
      [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($destination)) | Out-Null
      Copy-Item -LiteralPath $_.FullName -Destination $destination
    }
}

# Keep the historical integration-test paths at generated/*.
Publish-All ./cogsburger ./generated -IntegrationLayout
Publish-All ./conformance/model ./generated/conformance
Invoke-Cogs cogs-new --overwrite ./generated/new-model
Publish-All ./generated/new-model ./generated/new-model-artifacts

$firstManifest = Get-TreeManifest ./generated
$firstTurtleRoot = Join-Path $env:RUNNER_TEMP "cogs-first-turtle-$([guid]::NewGuid().ToString('N'))"
Copy-TurtleTree ./generated $firstTurtleRoot
Publish-All ./cogsburger ./generated -IntegrationLayout
Publish-All ./conformance/model ./generated/conformance
Publish-All ./generated/new-model ./generated/new-model-artifacts
$secondManifest = Get-TreeManifest ./generated
$drift = @(Compare-Object -ReferenceObject $firstManifest -DifferenceObject $secondManifest)
if ($drift.Count -ne 0) {
  $details = $drift | Select-Object -First 20 | Out-String
  throw "A second publisher regeneration changed a non-Turtle artifact or file inventory:`n$details"
}

$rdfComparer = [IO.Path]::GetFullPath(
  './conformance/dotnet/Cogs.Conformance.RdfGraphComparer/bin/Release/net10.0/Cogs.Conformance.RdfGraphComparer.dll')
& dotnet $rdfComparer $firstTurtleRoot ./generated
if ($LASTEXITCODE -ne 0) {
  throw "A second publisher regeneration changed a Turtle RDF graph (exit $LASTEXITCODE)."
}

