param()
$ErrorActionPreference='Stop'
$auditRoot=$PSScriptRoot
$source=Join-Path $auditRoot 'source'
$probes=Join-Path $auditRoot 'probes'
$logs=Join-Path $auditRoot 'logs'
if(Test-Path -LiteralPath "$probes/models"){throw 'Use a fresh extraction: probes/models already exists.'}
if(-not(Test-Path -LiteralPath "$source/Cogs.Console.sln")){throw 'Place an archive of the audited revision in the source subdirectory first.'}
foreach($name in @('COGS_PYTHON','COGS_NODE','COGS_NPM')){
  $value=[Environment]::GetEnvironmentVariable($name)
  if([string]::IsNullOrWhiteSpace($value) -or -not(Test-Path -LiteralPath $value -PathType Leaf)){throw "Set $name to the full executable path."}
}
$env:PATH="$([IO.Path]::GetDirectoryName($env:COGS_NODE));$env:PATH"
New-Item -ItemType Directory -Path $logs -Force | Out-Null
Set-Location -LiteralPath $source
[Environment]::CurrentDirectory=$source
& $env:COGS_PYTHON -c 'import sys,pydantic,jsonschema; print(sys.version); print(pydantic.__version__); assert sys.version_info >= (3,11)'
if($LASTEXITCODE -ne 0){throw 'Python dependencies unavailable'}
& $env:COGS_NODE --version
& dotnet restore Cogs.Console.sln --verbosity minimal *> "$logs/reproduction-restore.log"
if($LASTEXITCODE -ne 0){throw 'Restore failed'}
& dotnet build Cogs.Console.sln --configuration Release --no-restore --verbosity minimal *> "$logs/reproduction-build.log"
if($LASTEXITCODE -ne 0){throw 'Build failed'}
& $env:COGS_PYTHON "$probes/prepare.py"
if($LASTEXITCODE -ne 0){throw 'Fixture generation failed'}
& $env:COGS_PYTHON "$probes/extra_models.py"
if($LASTEXITCODE -ne 0){throw 'Unicode fixture failed'}
& $env:COGS_PYTHON "$probes/python_probe.py" py > "$logs/python-probes.json"
if($LASTEXITCODE -ne 0){throw 'Python probe failed'}
& $env:COGS_PYTHON "$probes/python_probe.py" pydantic > "$logs/pydantic-probes.json"
if($LASTEXITCODE -ne 0){throw 'Pydantic probe failed'}
$manifest="$probes/generated/ts/package.json"
$before=(Get-FileHash -LiteralPath $manifest).Hash
Push-Location -LiteralPath "$probes/generated/ts"
try {
  & $env:COGS_NPM install --no-save --ignore-scripts --no-package-lock typescript@6.0.3 '@xmldom/xmldom@0.9.10' *> "$logs/reproduction-npm.log"
  if($LASTEXITCODE -ne 0){throw 'npm install failed'}
}finally{Pop-Location}
if((Get-FileHash -LiteralPath $manifest).Hash -cne $before){throw 'npm changed the package manifest'}
& $env:COGS_NPM --prefix "$probes/generated/ts" run build *> "$logs/reproduction-ts-build.log"
if($LASTEXITCODE -ne 0){throw 'TypeScript build failed'}
& $env:COGS_NODE "$probes/typescript_probe.mjs" > "$logs/typescript-probes.json"
if($LASTEXITCODE -ne 0){throw 'TypeScript probe failed'}
& dotnet build "$probes/Probe.csproj" --configuration Release --verbosity minimal *> "$logs/reproduction-probe-build.log"
if($LASTEXITCODE -ne 0){throw 'C# probe build failed'}
& dotnet "$probes/bin/Release/net10.0/Probe.dll" $probes > "$logs/csharp-probes.json"
if($LASTEXITCODE -ne 0){throw 'C# probe failed'}
& $env:COGS_PYTHON "$probes/variant_probe.py" > "$logs/variant-probes.json"
if($LASTEXITCODE -ne 0){throw 'Variant probe failed'}
& $env:COGS_NODE "$probes/native_limits.mjs" > "$logs/native-js-limits.json"
if($LASTEXITCODE -ne 0){throw 'Native JavaScript probe failed'}
& dotnet "$source/Cogs.Console/bin/Release/net10.0/cogs.dll" publish-json "$source/conformance/model" "$source/generated/conformance/json" *> "$logs/reproduction-conformance-json.log"
if($LASTEXITCODE -ne 0){throw 'Conformance JSON generation failed'}
& $env:COGS_PYTHON "$probes/independent_schema.py" > "$logs/independent-schema.json"
if($LASTEXITCODE -ne 0){throw 'Independent schema probe failed'}
Write-Output "Boundary observations are in $logs. Expected defects are recorded as data, not treated as script failures."
