COGS 2 release review evidence
Audited revision: 9c5c7c354d2a4a95d89d2a1e46146a2d9fa874da
Report: docs/reviews/cogs-2-release-review.md

The evidence/ directory contains original observations and individual test
results. It is immutable historical evidence; a new reproduction writes logs/.
Scripts are audit fixtures only, not product changes or normative assertions.
Expected correctness failures are recorded as data.

To reproduce the independent boundary review on Windows:
1. Extract this archive into a fresh disposable directory, for example
   D:/svn/cogs/out/review-reproduction. Do not extract over an existing model.
2. From the COGS repository, archive the exact revision:
   git archive --format=zip --output=<fresh-directory>/source.zip 9c5c7c354d2a4a95d89d2a1e46146a2d9fa874da
3. Expand source.zip into <fresh-directory>/source. This isolates builds and
   generated artifacts from the production checkout and existing output.
4. Supply .NET SDK 10 and PowerShell 7. Set COGS_PYTHON, COGS_NODE and COGS_NPM
   to complete executable paths. The audit used Python 3.11.9, Pydantic 2.13.5,
   jsonschema 4.26.0, Node 22.23.1 and npm 10.9.8. Install Python dependencies
   into a dedicated environment, not an unrelated application interpreter.
5. Execute reproduce-boundaries.ps1 from the fresh extraction. It generates
   C#/Python/Pydantic/TypeScript plus both schemas and runs 19 instance cases,
   the pattern and Unicode model variants, native API probes and independent
   JSON Schema closure checks. TypeScript 6.0.3 and xmldom 0.9.10 are installed
   locally with scripts/lockfile/manifest changes disabled.
6. Compare semantic observations in logs/ with evidence/. Do not compare
   absolute paths, compiler progress, timestamps or diagnostic line endings.

TypeScript 6.0.0, declared in the repository's tool manifest, was unavailable
from npm during this review. The normal workflow resolved 6.0.3 / xmldom
0.9.12; an additional complete runtime/integration check used 6.0.3 / 0.9.10.

The recipes/ directory preserves the seven workflow bodies executed for the
broader release checks. Follow AGENTS.md and .github/workflows/build.yml at
the audited revision for complete environment provisioning and baseline
commands. These recipes may replace generated output: run them only in the
isolated source archive. No tooling binaries, node_modules or generated model
packages are included in this evidence archive.

Log interpretation:
- Empty cogsJson/cogsXml strings mean no authoritative validator diagnostics.
- Raw JSON validity is True/False; empty rawXml means no XSD diagnostics.
- ERROR: prefixes record runtime/parser failures rather than aborting a case.
- boundary-validation.json validates every successfully emitted probe boundary.
- native-probes.json records constructed C# values and native conversion results.
- Native JSON.stringify examples are independent platform observations.
- The downstream report counts source CSV rows, not deployed instance values.
- GitHub API files record the exact SHA and hosted job/step conclusions; raw
  hosted logs and runner image provenance were not downloaded.
