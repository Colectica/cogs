import csv, pathlib, shutil
root=pathlib.Path(__file__).resolve().parent
target=root/'models/unicode-length'
shutil.copytree(root/'models/base',target,dirs_exist_ok=True)
path=target/'ItemTypes/Record/Record.csv'
with path.open(encoding='utf-8',newline='') as f:
    rows=list(csv.DictReader(f)); keys=list(rows[0])
row=next(r for r in rows if r['Name']=='Text'); row['MaxLength']='1'
with path.open('w',encoding='utf-8',newline='') as f:
    w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerow(row)
