import csv,json,pathlib,subprocess,sys
from jsonschema import Draft202012Validator
ROOT=pathlib.Path(__file__).resolve().parent.parent
CLI=ROOT/'source/Cogs.Console/bin/Release/net10.0/cogs.dll'
out=[]
cases=[('pattern-newline','\nx\n'),('pattern-subtraction','b'),('pattern-lazy','aaa')]
for model,value in cases:
    instance={'items':[{'$type':'Record','ID':'one','Text':value}]}
    directory=ROOT/'probes/variant-instances'/model
    directory.mkdir(parents=True,exist_ok=True)
    (directory/'instance.json').write_text(json.dumps(instance))
    (directory/'instance.xml').write_text(f'<ItemContainer xmlns="urn:cogs:audit"><Record><ID>one</ID><Text>{value}</Text></Record></ItemContainer>')
    result={'model':model,'value':value}
    for fmt in ['json','xml']:
        p=subprocess.run(['dotnet',str(CLI),'validate-instance',str(ROOT/'probes/models'/model),str(directory/f'instance.{fmt}'),'--format',fmt],capture_output=True,text=True,encoding='utf-8')
        result[fmt]={'exit':p.returncode,'output':p.stdout+p.stderr}
    schema=json.loads((ROOT/'probes/variants'/model/'publish-json/jsonSchema.json').read_text())
    result['independentJson']=Draft202012Validator(schema).is_valid(instance)
    out.append(result)
print(json.dumps(out,indent=2))
