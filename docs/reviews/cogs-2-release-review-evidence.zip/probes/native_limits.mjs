import {ItemContainer} from './generated/ts/dist/index.js';
function attempt(fn){try{return fn();}catch(e){return `${e.name}: ${e.message}`;}}
const ints=['9007199254740991','9007199254740992','9007199254740993','9223372036854775807'];
const decimals=['0.1','0.10000000000000001','1.234567890123456789','0.0000001','1000000000000000000000'];
const ids='{"items":[{"$type":"Record","ID":"a\\rb"},{"$type":"Record","ID":"a\\nb"}]}';
console.log(JSON.stringify({
 integers:ints.map(v=>[v,JSON.stringify(JSON.parse(v))]),
 decimals:decimals.map(v=>[v,JSON.stringify(JSON.parse(v))]),
 numeric:{negativeZero:Object.is(JSON.parse('-0'),-0),negativeZeroString:JSON.stringify(-0),overflow:JSON.stringify(JSON.parse('1e400')),smallestSubnormal:Number.MIN_VALUE,underflow:JSON.stringify(JSON.parse('1e-400'))},
 regex:{subtraction:new RegExp('[a-z-[aeiou]]').test('b'),newline:new RegExp('x').test('\nx\n')},
 crLfIdentity:attempt(()=>ItemContainer.fromXml(ItemContainer.fromJson(ids).toXml()).toJson()),
 datetimePrecision:new Date('2020-01-01T00:00:00.123456Z').toISOString()
},null,2));
