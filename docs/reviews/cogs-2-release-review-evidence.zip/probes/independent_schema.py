import copy,decimal,json,pathlib
from jsonschema import Draft202012Validator
root=pathlib.Path(__file__).resolve().parent.parent
schema=json.loads((root/'source/generated/conformance/json/jsonSchema.json').read_text(),parse_float=decimal.Decimal)
value=json.loads((root/'source/conformance/instances/full.json').read_text(),parse_float=decimal.Decimal)
validator=Draft202012Validator(schema)
cases=[('full',value,True)]
for name,change in [
    ('unknown-root',lambda d:d.update(Unknown='x')),
    ('unknown-derived-item',lambda d:d['items'][0].update(Unknown='x')),
    ('unknown-nested-composite',lambda d:d['items'][0]['Details'].update(Unknown='x')),
    ('unknown-reference',lambda d:d['topLevelReferences'][0].update(Unknown='x')),
    ('abstract-discriminator',lambda d:d['items'][0].update({'$type':'Entity'})),
    ('missing-inherited-id',lambda d:d['items'][0].pop('ID')),
]:
    changed=copy.deepcopy(value);change(changed);cases.append((name,changed,False))
print(json.dumps([dict(name=name,expected=expected,actual=validator.is_valid(v)) for name,v,expected in cases],indent=2))
