using System.Text.Json;
using System.Xml;
using System.Xml.Linq;
using Cogs.Dto;
using Cogs.Model;
using Cogs.Publishers;
using Cogs.Publishers.FluentJson;
using Json.Schema;

var root = args[0];
var loaded = new CogsDirectoryReader().LoadResult(Path.Combine(root,"models/base"));
var built = new CogsModelBuilder().BuildResult(loaded.Model);
if (!built.Success) throw new Exception(string.Join(";",built.Diagnostics));
var model = built.Model!;
var schema = new FluentJsonSchemaPublisher().BuildSchema(model);
var xp = new XmlSchemaPublisher { CogsLocation=model.SourceDirectory??"", CogsModel=model,TargetNamespace=model.Settings.NamespaceUrl,TargetNamespacePrefix=model.Settings.NamespacePrefix, TargetDirectory="." };
var xsd=xp.BuildSchemaSet();
string Attempt(Func<string> action) { try { return action(); } catch(Exception e) { return "ERROR: "+e.GetType().Name+": "+e.Message; } }
using var cases=JsonDocument.Parse(File.ReadAllText(Path.Combine(root,"cases.json")));
var output=new List<object>();
foreach(var c in cases.RootElement.EnumerateArray()) {
    string json=c.GetProperty("json").GetString()!,xml=c.GetProperty("xml").GetString()!;
    output.Add(new {
      name=c.GetProperty("name").GetString(),
      cogsJson=Attempt(()=>string.Join(" | ",CogsInstanceValidator.ValidateJson(model,json).Select(e=>e.Code+": "+e.Message))),
      rawJson=Attempt(()=>schema.Evaluate(JsonDocument.Parse(json).RootElement,new EvaluationOptions{RequireFormatValidation=false}).IsValid.ToString()),
      cogsXml=Attempt(()=>string.Join(" | ",CogsInstanceValidator.ValidateXml(model,xml).Select(e=>e.Code+": "+e.Message))),
      rawXml=Attempt(()=>{var es=new List<string>();var d=XDocument.Parse(xml,LoadOptions.PreserveWhitespace);System.Xml.Schema.Extensions.Validate(d,xsd,(_,e)=>es.Add(e.Message));return string.Join(" | ",es);}),
      csharpJson=Attempt(()=>Audit.Model.ItemContainer.FromJson(json).ToJson()),
      csharpXml=Attempt(()=>Audit.Model.ItemContainer.FromXml(xml).ToJson()),
      emittedXml=Attempt(()=>Audit.Model.ItemContainer.FromJson(json).ToXml()),
      csharpJsonXmlJson=Attempt(()=>Audit.Model.ItemContainer.FromXml(Audit.Model.ItemContainer.FromJson(json).ToXml()).ToJson())
    });
}
var unicodeModel = new CogsModelBuilder().BuildResult(new CogsDirectoryReader().LoadResult(Path.Combine(root,"models/unicode-length")).Model).Model!;
var unicodeSchema = new FluentJsonSchemaPublisher().BuildSchema(unicodeModel);
var unicodeJson="{\"items\":[{\"$type\":\"Record\",\"ID\":\"one\",\"Text\":\"😀\"}]}";
var unicodeXml="<ItemContainer xmlns=\"urn:cogs:audit\"><Record><ID>one</ID><Text>😀</Text></Record></ItemContainer>";
File.WriteAllText(Path.Combine(root,"../logs/unicode-probes.json"),JsonSerializer.Serialize(new {
  cogsJson=CogsInstanceValidator.ValidateJson(unicodeModel,unicodeJson).Select(e=>e.Code+": "+e.Message),
  rawJson=unicodeSchema.Evaluate(JsonDocument.Parse(unicodeJson).RootElement).IsValid,
  cogsXml=CogsInstanceValidator.ValidateXml(unicodeModel,unicodeXml).Select(e=>e.Code+": "+e.Message),
},new JsonSerializerOptions{WriteIndented=true}));
var boundaries=new List<object>();
foreach (var runtime in new[]{"python","pydantic","typescript"}) {
  using var results=JsonDocument.Parse(File.ReadAllText(Path.Combine(root,$"../logs/{runtime}-probes.json")));
  foreach(var result in results.RootElement.EnumerateArray()) foreach(var field in new[]{"json","xml","jsonXmlJson","emittedXml"}) {
    var wire=result.GetProperty(field).GetString()!;
    if(wire.StartsWith("ERROR:")) continue;
    bool isXml=field=="emittedXml";
    boundaries.Add(new{runtime,name=result.GetProperty("name").GetString(),field,
      cogs=Attempt(()=>string.Join(" | ",(isXml?CogsInstanceValidator.ValidateXml(model,wire):CogsInstanceValidator.ValidateJson(model,wire)).Select(e=>e.Code+": "+e.Message))),
      rawSchema=Attempt(()=>isXml?ValidateXsd(wire):schema.Evaluate(JsonDocument.Parse(wire).RootElement,new EvaluationOptions{RequireFormatValidation=false}).IsValid.ToString())});
  }
}
string ValidateXsd(string wire) {var es=new List<string>();var doc=XDocument.Parse(wire,LoadOptions.PreserveWhitespace);System.Xml.Schema.Extensions.Validate(doc,xsd,(_,e)=>es.Add(e.Message));return string.Join(" | ",es);}
foreach(var result in JsonSerializer.SerializeToElement(output).EnumerateArray()) foreach(var field in new[]{"csharpJson","csharpXml","csharpJsonXmlJson","emittedXml"}) {
  var wire=result.GetProperty(field).GetString()!;
  if(wire.StartsWith("ERROR:")) continue;
  bool isXml=field=="emittedXml";
  boundaries.Add(new{runtime="csharp",name=result.GetProperty("name").GetString(),field,
    cogs=Attempt(()=>string.Join(" | ",(isXml?CogsInstanceValidator.ValidateXml(model,wire):CogsInstanceValidator.ValidateJson(model,wire)).Select(e=>e.Code+": "+e.Message))),
    rawSchema=Attempt(()=>isXml?ValidateXsd(wire):schema.Evaluate(JsonDocument.Parse(wire).RootElement,new EvaluationOptions{RequireFormatValidation=false}).IsValid.ToString())});
}
File.WriteAllText(Path.Combine(root,"../logs/boundary-validation.json"),JsonSerializer.Serialize(boundaries,new JsonSerializerOptions{WriteIndented=true}));
var nativeContainer = new Audit.Model.ItemContainer();
nativeContainer.Items.Add(new Audit.Model.Record{ID="native", PositiveValue=-1});
var nativeResults=new {
  negativePositiveJson=Attempt(()=>nativeContainer.ToJson()),
  negativePositiveXml=Attempt(()=>nativeContainer.ToXml()),
  negativePositiveReparse=Attempt(()=>Audit.Model.ItemContainer.FromJson(nativeContainer.ToJson()).ToJson()),
  subTickDuration=Attempt(()=>DurationConversion("PT0.00000001S")),
  bigDuration=Attempt(()=>DurationConversion("P99999999999999999999999D"))
};
string DurationConversion(string lexical){var t=typeof(Audit.Model.Record).GetProperty("Elapsed")!.PropertyType;var d=Activator.CreateInstance(t,lexical);object?[] a=[null];var ok=t.GetMethod("TryGetTimeSpan")!.Invoke(d,a);return ok+":"+a[0];}
File.WriteAllText(Path.Combine(root,"../logs/native-probes.json"),JsonSerializer.Serialize(nativeResults,new JsonSerializerOptions{WriteIndented=true}));
Console.WriteLine(JsonSerializer.Serialize(output,new JsonSerializerOptions{WriteIndented=true}));
