import csv, json, pathlib, subprocess, sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
SOURCE = ROOT / 'source'
CLI = SOURCE / 'Cogs.Console/bin/Release/net10.0/cogs.dll'
HEADERS = 'Name,DataType,MinCardinality,MaxCardinality,Description,Ordered,AllowSubtypes,MinLength,MaxLength,Enumeration,Pattern,MinInclusive,MinExclusive,MaxInclusive,MaxExclusive,DeprecatedNamespace,DeprecatedElementOrAttribute,DeprecatedChoiceGroup'.split(',')

def write_csv(path, headers, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=headers)
        writer.writeheader()
        writer.writerows(rows)

def prop(name, typ, **kwargs):
    return dict(Name=name, DataType=typ, MinCardinality='0', MaxCardinality='1', **kwargs)

def model(name, props):
    root = ROOT / 'probes/models' / name
    (root / 'CompositeTypes').mkdir(parents=True, exist_ok=True)
    settings = {'CogsVersion':'2.0', 'Title':'Audit Model', 'ShortTitle':'Audit', 'Slug':'audit_model', 'Description':'Release audit fixture', 'Version':'2.0.0', 'Author':'', 'Copyright':'', 'NamespaceUrl':'urn:cogs:audit', 'NamespacePrefix':'a', 'CSharpNamespace':'Audit.Model'}
    write_csv(root/'Settings/Settings.csv', ['Key','Value'], [dict(Key=k,Value=v) for k,v in settings.items()])
    write_csv(root/'Settings/Identification.csv', HEADERS, [dict(Name='ID',DataType='string',MinCardinality='1',MaxCardinality='1')])
    write_csv(root/'ItemTypes/Record/Record.csv', HEADERS, props)
    return root

base = model('base', [prop('Text','string'), prop('Link','anyURI'), prop('FloatValue','float'), prop('DoubleValue','double'), prop('DecimalValue','decimal'), prop('IntValue','int'), prop('PositiveValue','positiveInteger'), prop('Observed','dateTime'), prop('Elapsed','duration'), prop('MomentEnum','dateTime',Enumeration='2020-01-01T00:00:00Z'), prop('DurationEnum','duration',Enumeration='P1Y'), prop('Caption','langString')])
variants = {
 'unicode-enum':[prop('Text','string',Enumeration='😀',MaxLength='1')],
 'pattern-lazy':[prop('Text','string',Pattern='a+?')],
 'pattern-subtraction':[prop('Text','string',Pattern='[a-z-[aeiou]]')],
 'pattern-newline':[prop('Text','string',Pattern='x')],
 'pattern-dollar':[prop('Text','string',Pattern=r'\$')],
 'float-enum':[prop('FloatValue','float',Enumeration='1.00000006 1.00000007')],
 'float-range':[prop('FloatValue','float',MinInclusive='1e100')],
 'decimal-enum':[prop('DecimalValue','decimal',Enumeration='1.2 1.20')],
}
for name, props in variants.items(): model(name,props)

def case(name, fields, elements='', identity='one'):
    return dict(name=name, json=json.dumps({'items':[{'$type':'Record','ID':identity, **fields}]},ensure_ascii=True), xml=f'<ItemContainer xmlns="urn:cogs:audit"><Record><ID>{identity}</ID>{elements}</Record></ItemContainer>')

cases = [
 case('float-rounding', {'FloatValue':1.00000006}, '<FloatValue>1.00000006</FloatValue>'),
 case('float-underflow', {'FloatValue':1e-50}, '<FloatValue>1e-50</FloatValue>'),
 case('float-overflow', {'FloatValue':1e100}, '<FloatValue>1e100</FloatValue>'),
 case('uri-space', {'Link':'a b'}, '<Link>a b</Link>'),
 case('uri-ipv6', {'Link':'http://[z]/'}, '<Link>http://[z]/</Link>'),
 case('uri-fragments', {'Link':'path#x#y'}, '<Link>path#x#y</Link>'),
 case('xml-integer-plus-leading-zeros', {'IntValue':1}, '<IntValue>+001</IntValue>'),
 case('xml-decimal-plus-leading-zeros', {'DecimalValue':1.25}, '<DecimalValue>+001.2500</DecimalValue>'),
 case('xml-decimal-leading-dot', {'DecimalValue':0.5}, '<DecimalValue>.5</DecimalValue>'),
 case('datetime-equivalent-enum', {'MomentEnum':'2019-12-31T19:00:00-05:00'}, '<MomentEnum>2019-12-31T19:00:00-05:00</MomentEnum>'),
 case('duration-equivalent-enum', {'DurationEnum':'P12M'}, '<DurationEnum>P12M</DurationEnum>'),
 case('carriage-return-text', {'Text':'a\rb'}, '<Text>a&#13;b</Text>'),
 case('carriage-return-identity', {'Text':'one'}, '<Text>one</Text>', 'a&#13;b'),
 case('xml-forbidden-control', {'Text':'a\u0001b'}, '<Text>a&#1;b</Text>'),
]
cases[12]['json']=json.dumps({'items':[{'$type':'Record','ID':'a\rb','Text':'one'}]})
cases.append(dict(name='integer-json-decimal',json='{"items":[{"$type":"Record","ID":"one","IntValue":1.0}]}',xml='<ItemContainer xmlns="urn:cogs:audit"><Record><ID>one</ID><IntValue>1</IntValue></Record></ItemContainer>'))
cases.append(dict(name='integer-json-exponent',json='{"items":[{"$type":"Record","ID":"one","IntValue":1e2}]}',xml='<ItemContainer xmlns="urn:cogs:audit"><Record><ID>one</ID><IntValue>100</IntValue></Record></ItemContainer>'))
cases.append(dict(name='double-overflow',json='{"items":[{"$type":"Record","ID":"one","DoubleValue":1e400}]}',xml='<ItemContainer xmlns="urn:cogs:audit"><Record><ID>one</ID><DoubleValue>1e400</DoubleValue></Record></ItemContainer>'))
for field in ['FloatValue','DoubleValue']:
    cases.append(dict(name=field.lower()+'-negative-zero',json='{"items":[{"$type":"Record","ID":"one","'+field+'":-0}]}',xml='<ItemContainer xmlns="urn:cogs:audit"><Record><ID>one</ID><'+field+'>-0</'+field+'></Record></ItemContainer>'))
(ROOT/'probes/cases.json').write_text(json.dumps(cases,indent=2),encoding='utf-8')
commands=[('publish-cs',['--csproj','--nullable'],'cs'),('publish-py',[],'py'),('publish-py',['--flavor','pydantic'],'pydantic'),('publish-ts',[],'ts'),('publish-json',[],'json'),('publish-xsd',[],'xsd')]
with (ROOT/'logs/probe-preparation.log').open('w',encoding='utf-8') as log:
    for command, flags, directory in commands:
        args=['dotnet',str(CLI),command,*flags,str(base),str(ROOT/'probes/generated'/directory)]
        p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
        log.write(f'{args!r}\nexit={p.returncode}\n{p.stdout}\n')
        if p.returncode: raise RuntimeError(p.stdout)
    for name in variants:
        for command in ['validate','publish-json','publish-xsd']:
            args=['dotnet',str(CLI),command,str(ROOT/'probes/models'/name)]
            if command!='validate': args.append(str(ROOT/'probes/variants'/name/command))
            p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
            log.write(f'{name} {command} exit={p.returncode}\n{p.stdout}\n')
print('Prepared',len(cases),'instance probes and',len(variants),'model variants')
