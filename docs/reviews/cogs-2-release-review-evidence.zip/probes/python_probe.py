import importlib,json,pathlib,sys
root=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(root/'generated'/sys.argv[1]))
c=importlib.import_module('audit_model')
def attempt(fn):
    try: return fn()
    except Exception as e: return f'ERROR: {type(e).__name__}: {e}'
out=[]
for case in json.loads((root/'cases.json').read_text()):
    out.append(dict(name=case['name'], json=attempt(lambda:c.ItemContainer.from_json(case['json']).to_json()), xml=attempt(lambda:c.ItemContainer.from_xml(case['xml']).to_json()), jsonXmlJson=attempt(lambda:c.ItemContainer.from_xml(c.ItemContainer.from_json(case['json']).to_xml()).to_json()), emittedXml=attempt(lambda:c.ItemContainer.from_json(case['json']).to_xml())))
print(json.dumps(out,indent=2))
