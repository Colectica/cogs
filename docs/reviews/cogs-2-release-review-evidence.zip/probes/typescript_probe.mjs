import fs from 'node:fs';
import {ItemContainer} from './generated/ts/dist/index.js';
const cases=JSON.parse(fs.readFileSync(new URL('./cases.json',import.meta.url),'utf8'));
function attempt(fn){try{return fn();}catch(e){return `ERROR: ${e.name}: ${e.message}`;}}
const out=cases.map(c=>({name:c.name,json:attempt(()=>ItemContainer.fromJson(c.json).toJson()),xml:attempt(()=>ItemContainer.fromXml(c.xml).toJson()),jsonXmlJson:attempt(()=>ItemContainer.fromXml(ItemContainer.fromJson(c.json).toXml()).toJson()),emittedXml:attempt(()=>ItemContainer.fromJson(c.json).toXml())}));
console.log(JSON.stringify(out,null,2));
