$ErrorActionPreference='Stop'
$auditRoot=$PSScriptRoot
$safetyRoot=Join-Path $auditRoot 'probes/safety-case'
$source=Join-Path $safetyRoot 'source'
$cli=Join-Path $auditRoot 'source/Cogs.Console/bin/Release/net10.0/cogs.dll'
New-Item -ItemType Directory -Path $safetyRoot -Force | Out-Null
Copy-Item -LiteralPath "$auditRoot/probes/models/base" -Destination $source -Recurse
$before=@(Get-ChildItem -LiteralPath $source -Recurse -File|Get-FileHash|ForEach-Object Hash)
$results=[Collections.Generic.List[object]]::new()
foreach($target in @($source,(Join-Path $source 'child'),$safetyRoot)){
  $output=& dotnet $cli publish-json --overwrite $source $target 2>&1|Out-String
  $results.Add([pscustomobject]@{target=$target;exit=$LASTEXITCODE;output=$output})
}
$alias=Join-Path $safetyRoot 'alias'
try {
  New-Item -ItemType SymbolicLink -Path $alias -Target $source | Out-Null
  $output=& dotnet $cli publish-json --overwrite $source (Join-Path $alias 'output') 2>&1|Out-String
  $results.Add([pscustomobject]@{target=$alias;exit=$LASTEXITCODE;output=$output})
} catch {$results.Add([pscustomobject]@{target=$alias;unavailable=$_.Exception.Message})}
$after=@(Get-ChildItem -LiteralPath $source -Recurse -File|Get-FileHash|ForEach-Object Hash)
$results.Add([pscustomobject]@{sourceHashUnchanged=([string]::Join(',', $before) -ceq [string]::Join(',', $after))})
$results|ConvertTo-Json|Set-Content -LiteralPath "$auditRoot/logs/path-probes.json"
Write-Output 'Disposable path checks recorded.'
