sphinx-build -W --keep-going -b html ./generated/sphinx/source ./generated/sphinx/build/html
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
sphinx-build -W --keep-going -b html ./generated/conformance/sphinx/source ./generated/conformance/sphinx/build/html
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
sphinx-build -W --keep-going -b html ./generated/new-model-artifacts/sphinx/source ./generated/new-model-artifacts/sphinx/build/html
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
sphinx-build -W --keep-going -b html ./docs/source ./docs/build/html
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
