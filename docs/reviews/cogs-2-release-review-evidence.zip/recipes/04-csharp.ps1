$roots = @(
  './generated/src',
  './generated/conformance/src',
  './generated/new-model-artifacts/src'
)
foreach ($root in $roots) {
  $projects = @(Get-ChildItem $root -Filter *.csproj -File)
  if ($projects.Count -ne 1) { throw "Expected one generated C# project below $root, found $($projects.Count)." }
  dotnet build $projects[0].FullName --configuration Release --verbosity minimal
  if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
