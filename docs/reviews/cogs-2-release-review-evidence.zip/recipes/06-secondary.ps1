./conformance/scripts/Test-SecondaryArtifacts.ps1 `
  -Roots @('./generated', './generated/conformance', './generated/new-model-artifacts')
$linkmlRoots = @(
  './generated/linkml',
  './generated/conformance/linkml',
  './generated/new-model-artifacts/linkml'
)
foreach ($root in $linkmlRoots) {
  linkml-lint --validate --ignore-warnings "$root/linkml.yml"
  if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
  gen-python --validate "$root/linkml.yml" |
    Set-Content -LiteralPath "$root/linkml_model.py" -Encoding utf8
  if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
& $env:COGS_PYTHON -m py_compile `
  ./generated/linkml/linkml_model.py `
  ./generated/conformance/linkml/linkml_model.py `
  ./generated/new-model-artifacts/linkml/linkml_model.py
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
node ./conformance/node/validate-graphql.mjs `
  ./generated/graphql/GraphQL.graphqls `
  ./generated/conformance/graphql/GraphQL.graphqls `
  ./generated/new-model-artifacts/graphql/GraphQL.graphqls
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
$owlFiles = @(
  Get-ChildItem `
    ./generated/owl, `
    ./generated/conformance/owl, `
    ./generated/new-model-artifacts/owl `
    -Filter *.ttl -File | Select-Object -ExpandProperty FullName
)
if ($owlFiles.Count -ne 3) {
  throw "Expected three generated Turtle ontologies, found $($owlFiles.Count)."
}
java -jar ./conformance/java/target/owl-profile-validator.jar @owlFiles
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
