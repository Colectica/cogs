import collections,csv,json,pathlib,subprocess
root=pathlib.Path(__file__).resolve().parent
definition=json.loads((root/'source/conformance/downstream/snapshots.json').read_text())
cli=root/'source/Cogs.Console/bin/Release/net10.0/cogs.dll'
results=[]
for model in definition['models']:
    destination=root/'downstream'/model['id']
    destination.parent.mkdir(exist_ok=True)
    subprocess.run(['git','clone','--quiet','--filter=blob:none','--no-checkout',model['url'],str(destination)],check=True)
    subprocess.run(['git','-C',str(destination),'checkout','--quiet','--detach',model['commit']],check=True)
    revision=subprocess.check_output(['git','-C',str(destination),'rev-parse','HEAD'],text=True).strip()
    counts=collections.Counter(); examples=collections.defaultdict(list)
    for f in destination.rglob('*.csv'):
        if '.git' in f.parts:continue
        with f.open(encoding='utf-8-sig',newline='') as stream:
            for row in csv.DictReader(stream):
                typ=row.get('DataType','')
                if typ:
                    counts[typ]+=1
                    if len(examples[typ])<3: examples[typ].append(str(f.relative_to(destination))+':'+row.get('Name',''))
    upgrade=subprocess.run(['dotnet',str(cli),'rewrite','--upgrade-cogs-2',str(destination)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8')
    (root/'logs'/f"downstream-{model['id']}-upgrade.log").write_text(upgrade.stdout,encoding='utf-8')
    diff=subprocess.check_output(['git','-C',str(destination),'status','--short'],text=True)
    results.append(dict(model=model['id'],revision=revision,counts=dict(counts),examples=dict(examples),upgradeExit=upgrade.returncode,gitStatusAfterUpgrade=diff))
    print(model['id'],revision,'upgrade exit',upgrade.returncode,'rows',sum(counts.values()))
(root/'logs/downstream-analysis.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
