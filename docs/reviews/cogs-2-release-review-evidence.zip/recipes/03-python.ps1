$packages = @(
  './generated/python', './generated/python-pydantic',
  './generated/conformance/python', './generated/conformance/python-pydantic',
  './generated/new-model-artifacts/python', './generated/new-model-artifacts/python-pydantic'
)
foreach ($package in $packages) {
  & $env:COGS_PYTHON -m compileall -q $package
  if ($LASTEXITCODE -ne 0) { throw "Python compilation failed for $package" }
  # The flavors share an import name: isolate each import in its own process.
  & $env:COGS_PYTHON -c 'import importlib, pathlib, sys, tomllib; root = pathlib.Path(sys.argv[1]); metadata = tomllib.loads((root / "pyproject.toml").read_text(encoding="utf-8")); sys.path.insert(0, str(root)); importlib.import_module(metadata["tool"]["setuptools"]["packages"][0])' $package
  if ($LASTEXITCODE -ne 0) { throw "Python import failed for $package" }
}
