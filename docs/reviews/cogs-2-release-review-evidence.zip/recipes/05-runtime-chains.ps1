./conformance/scripts/Test-GeneratedRuntimes.ps1 `
  -CogsDll ./Cogs.Console/bin/Release/net10.0/cogs.dll
