$packages = @(
  './generated/typescript',
  './generated/conformance/typescript',
  './generated/new-model-artifacts/typescript'
)
foreach ($package in $packages) {
  $manifest = Join-Path $package 'package.json'
  $manifestBefore = (Get-FileHash -LiteralPath $manifest -Algorithm SHA256).Hash
  if ($IsWindows) {
    # npm 10 on Windows either ignores a project-scoped --prefix
    # during install or treats its value as a package spec. Run the
    # install in the package while retaining --prefix for build.
    Push-Location $package
    try {
      npm install --ignore-scripts --no-package-lock
      if ($LASTEXITCODE -ne 0) { throw "npm install failed for $package with exit $LASTEXITCODE" }
    }
    finally {
      Pop-Location
    }
  }
  else {
    npm --prefix $package install --ignore-scripts --no-package-lock
    if ($LASTEXITCODE -ne 0) { throw "npm install failed for $package with exit $LASTEXITCODE" }
  }
  $manifestAfter = (Get-FileHash -LiteralPath $manifest -Algorithm SHA256).Hash
  if ($manifestAfter -cne $manifestBefore) {
    throw "npm install rewrote the generated manifest for $package"
  }
  npm --prefix $package run build
  if ($LASTEXITCODE -ne 0) { throw "npm build failed for $package with exit $LASTEXITCODE" }
  npm pack $package --dry-run
  if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
